<?php

// Silence is Golden